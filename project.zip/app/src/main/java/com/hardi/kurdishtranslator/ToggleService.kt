package com.hardi.kurdishtranslator

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * Appears in Settings → Accessibility. Once it is on, the accessibility button (or the volume-keys shortcut)
 * starts / stops the translator from anywhere, so the game never has to be left. It reads nothing from the screen.
 */
class ToggleService : AccessibilityService() {

    private val cb = object : AccessibilityButtonController.AccessibilityButtonCallback() {
        override fun onClicked(controller: AccessibilityButtonController) {
            toggle()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        try {
            accessibilityButtonController.registerAccessibilityButtonCallback(cb)
        } catch (e: Exception) {
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        try { accessibilityButtonController.unregisterAccessibilityButtonCallback(cb) } catch (e: Exception) {}
        return super.onUnbind(intent)
    }

    private fun toggle() {
        if (Bus.running && Bus.a11yPause) {
            // quick on / off: the app keeps running (no permission prompts), only listening is paused / resumed
            Bus.paused = !Bus.paused
            Bus.say(if (Bus.paused) "⏸ ڕاگیراوە — دووبارە دوگمەکە دابگرە" else "▶ بەردەوامە — گوێم لێیە")
            Toast.makeText(this, if (Bus.paused) "⏸ ڕاگیرا" else "▶ بەردەوام بوو", Toast.LENGTH_SHORT).show()
        } else if (Bus.running) {
            startService(Intent(this, TranslatorService::class.java).setAction(TranslatorService.ACTION_STOP))
            Toast.makeText(this, "⏹ وەرگێڕان وەستا", Toast.LENGTH_SHORT).show()
        } else {
            // starting needs the microphone / screen-audio permission flow, so the app opens, starts, and goes back
            val i = Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("auto", true)
            startActivity(i)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
