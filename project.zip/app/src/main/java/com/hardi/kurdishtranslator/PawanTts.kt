package com.hardi.kurdishtranslator

import android.annotation.SuppressLint
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * دەنگی کوردی لە tts.pawan.krd (خۆڕایی و خێرا، ئینتەرنێت دەوێت).
 * WebViewـێکی شاراوە ماڵپەڕەکە دەکاتەوە، دەق دەنووسێت و دوگمەی خوێندنەوە دادەگرێت؛ دەنگی دروستکراو (take) لە ماڵپەڕەکەوە
 * وەردەگیرێت و دەکرێت بە PCM16 مۆنۆ 24kHz — هەمان فۆرماتی KuVoice — بۆیە هەموو شتێکی تری ئەپەکە (کاش، کوژاندنەوەی دەنگی
 * ئەسڵی، وەستان/بەردەوامبوون، پاکێجی یاری) وەک خۆی کار دەکات. دەنگی WebViewـەکە خۆی بێدەنگ دەکرێت.
 *
 * کاربەر یەک جار لە PawanLoginActivity دەچێتە ژوورەوە و cookieـەکان لە CookieManager دەمێننەوە.
 * ئەگەر Pawan سەرکەوتوو نەبوو (ئینتەرنێت نییە، چوونەژوورەوە نییە، هەڵە)، Gem بە دەنگی ئۆفلاین دەگەڕێتەوە.
 */
object PawanTts {
    private const val TAG = "PawanTts"
    const val URL = "https://tts.pawan.krd/"
    const val OUT_RATE = 24000
    private const val LANG = "ckb"          // سۆرانی
    private const val MAX_CHUNK = 300       // پیت لە هەر داواکارییەکدا
    private const val TIMEOUT_S = 20L

    private val ui = Handler(Looper.getMainLooper())
    private var app: Context? = null

    fun init(c: Context) { if (app == null) app = c.applicationContext }

    private fun prefs() = app?.getSharedPreferences("p", Context.MODE_PRIVATE)

    /** ئایا کاربەر Pawan ی هەڵبژاردووە */
    fun enabled(): Boolean = prefs()?.getBoolean("pawan", false) ?: false

    /** "female" یان "male" */
    fun voice(): String = if (prefs()?.getString("pv", "female") == "male") "male" else "female"

    fun hasCookie(): Boolean = try {
        !CookieManager.getInstance().getCookie(URL).isNullOrBlank()
    } catch (_: Throwable) { false }

    /** Does the saved cookie include Cloudflare's "human check passed" cookie? */
    fun hasClearance(): Boolean = try {
        (CookieManager.getInstance().getCookie(URL) ?: "").contains("cf_clearance")
    } catch (_: Throwable) { false }

    fun isOnline(): Boolean = try {
        val cm = app!!.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (e: Throwable) { Log.w(TAG, "isOnline failed: " + e); false }

    /** هەڵبژێردراوە و چوونەژوورەوە کراوە (ئینتەرنێت لە کاتی بەکارهێنان پشکنین دەکرێت). */
    fun configured(): Boolean = app != null && enabled() && hasCookie()

    /** ئێستا بەکاردێت: هەڵبژێردراوە + چوونەژوورەوە + ئینتەرنێت */
    fun usable(): Boolean = configured() && isOnline()

    // ───────────── WebView (هەموو کارەکانی لەسەر main thread) ─────────────

    private var web: WebView? = null
    @Volatile private var pageReady = false
    private var loadedAt = 0L
    private var queued: (() -> Unit)? = null
    private var gen = 0
    private var onAudio: ((ByteArray) -> Unit)? = null
    private var onFail: ((String) -> Unit)? = null
    private var onEnd: ((String?) -> Unit)? = null
    private var onChunk: ((ByteArray) -> Unit)? = null   // live mode: pieces of the site's audio as they arrive
    private var onDone: (() -> Unit)? = null
    @Volatile var liveEpoch = 0                            // raised by cancel(): lines still waiting to be made are dropped

    /** WebViewـەکە پێشوەختە دەکاتەوە تا یەکەم ڕستە دوا نەکەوێت. */
    fun warmUp() {
        val a = app ?: return
        ui.post { try { ensureWeb(a) } catch (_: Throwable) {} }
    }

    /** دوای چوونەژوورەوە، پەڕەکە دووبارە بار دەکرێتەوە با cookieـی نوێ بەکار بێت. */
    fun reload() {
        ui.post { web?.let { pageReady = false; loadedAt = System.currentTimeMillis(); it.loadUrl(URL) } }
    }

    private class Bridge {
        @JavascriptInterface fun audio(tok: Int, b64: String) {
            val bytes = try { Base64.decode(b64, Base64.DEFAULT) } catch (_: Throwable) { null }
            ui.post {
                if (tok != gen) return@post
                if (bytes == null || bytes.isEmpty()) {
                    failNow("دەنگەکە بەتاڵ بوو")
                } else if (onChunk != null) {
                    // live mode, but the page gave the whole file at once: same thing, in one piece
                    val cc = onChunk; val dd = onDone
                    onChunk = null; onDone = null; onFail = null
                    cc?.invoke(bytes)
                    dd?.invoke()
                } else {
                    val cb = onAudio
                    onAudio = null; onFail = null
                    cb?.invoke(bytes)
                }
                stopPage()
            }
        }
        @JavascriptInterface fun failed(tok: Int, m: String) = ui.post { if (tok == gen) failNow(m) }
        /** live mode: one piece of the audio file (base64) */
        @JavascriptInterface fun chunk(tok: Int, b64: String) {
            val bytes = try { Base64.decode(b64, Base64.DEFAULT) } catch (_: Throwable) { null }
            if (bytes == null || bytes.isEmpty()) return
            ui.post { if (tok == gen) onChunk?.invoke(bytes) }
        }
        /** live mode: the whole audio has arrived */
        @JavascriptInterface fun sdone(tok: Int) = ui.post {
            if (tok == gen) {
                val cb = onDone
                onChunk = null; onDone = null; onFail = null
                cb?.invoke()
                stopPage()
            }
        }
        /** دۆخی ڕاستەوخۆ: ماڵپەڕەکە خۆی دەنگەکە پەخش کرد و تەواو بوو */
        @JavascriptInterface fun ended(tok: Int) = ui.post {
            if (tok == gen) { val cb = onEnd; onEnd = null; onFail = null; cb?.invoke(null) }
        }
    }

    private fun failNow(m: String) {
        val cb = onFail; onAudio = null; onFail = null; onEnd = null; onChunk = null; onDone = null
        cb?.invoke(m)
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    private fun ensureWeb(c: Context): WebView {
        web?.let { return it }
        val w = WebView(c)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        CookieManager.getInstance().setAcceptCookie(true)
        w.addJavascriptInterface(Bridge(), "AndroidTts")
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String?) {
                v.evaluateJavascript(HOOK_JS, null)
                pageReady = true
                queued?.also { queued = null }?.invoke()
            }
        }
        loadedAt = System.currentTimeMillis()
        w.loadUrl(URL)
        web = w
        return w
    }

    private fun stopPage() {
        web?.evaluateJavascript("window.__pawanStop && window.__pawanStop()", null)
    }

    private fun request(text: String, ok: (ByteArray) -> Unit, bad: (String) -> Unit) {
        val a = app ?: run { bad("Pawan ئامادە نەکراوە"); return }
        val my = ++gen
        onAudio = ok
        onFail = bad
        val w = ensureWeb(a)
        val run = {
            if (gen == my) {
                w.evaluateJavascript(
                    "window.__pawanSpeak(${JSONObject.quote(text)},${JSONObject.quote(voice())},${JSONObject.quote(LANG)},$my)", null
                )
            }
        }
        if (pageReady) run() else queued = run
    }

    private fun abort() {
        gen++
        queued = null
        onAudio = null
        onFail = null
        onEnd = null
        onChunk = null
        onDone = null
        stopPage()
    }

    /** class ی دەق: ماڵپەڕەکە خۆی دەیخوێنێتەوە (هەمان شێوازی مانگا) نەک PCM */
    class Line(val text: String)

    /** وەستاندنی خوێندنەوەی ڕاستەوخۆ (کاتێک پەخش دەوەستێت/پاک دەکرێتەوە) */
    fun cancel() {
        liveEpoch++
        ui.post {
            val cb = onEnd
            val liveFail = if (onChunk != null) onFail else null
            abort()
            cb?.invoke(null)
            liveFail?.invoke("وەستێنرا")
        }
    }

    /**
     * هەمان شێوازی مانگا: دەق دەخاتە ناو چوارگۆشەی ماڵپەڕەکە، دوگمەی خوێندنەوە دادەگرێت، ماڵپەڕەکە خۆی دەنگەکە دەپەخشێنێت،
     * و ئەم فەرمانە دەوەستێت تا پەخشەکە تەواو دەبێت. پاشان دەقی دواتر. لەسەر thread ی کار بانگ بکرێت.
     */
    fun speakDirect(text: String) {
        Bus.speakUntil = Long.MAX_VALUE
        try { speakDirect0(text) } finally { Bus.speakUntil = System.currentTimeMillis() + 500L }
    }

    private fun speakDirect0(text: String) {
        synchronized(lock) {
            val parts = chunk(text)
            var idx = 0
            var retried = 0
            while (idx < parts.size) {
                val c = parts[idx]
                val latch = CountDownLatch(1)
                val err = AtomicReference<String?>(null)
                ui.post {
                    val a = app
                    if (a == null) { err.set("Pawan ئامادە نەکراوە"); latch.countDown() }
                    else {
                        val my = ++gen
                        onAudio = null
                        onEnd = { e -> err.set(e); latch.countDown() }
                        onFail = { m -> err.set(m); latch.countDown() }
                        val w = ensureWeb(a)
                        // a page that has been open a long time may have lost its session / cookie: load it fresh
                        if (pageReady && System.currentTimeMillis() - loadedAt > 15 * 60_000L) {
                            pageReady = false
                            loadedAt = System.currentTimeMillis()
                            CookieManager.getInstance().flush()
                            w.loadUrl(URL)
                        }
                        val run = {
                            if (gen == my) {
                                w.evaluateJavascript(
                                    "window.__pawanSpeak(" + JSONObject.quote(c) + "," + JSONObject.quote(voice()) + "," +
                                        JSONObject.quote(LANG) + "," + my + ",true," + (gainPct() / 100.0) + "," +
                                        (ratePct() / 100.0) + "," + softPct() + ")", null
                                )
                            }
                        }
                        if (pageReady) run() else {
                            queued = run
                            // the page never finished loading (no internet, or Cloudflare is blocking it): say so soon
                            ui.postDelayed({
                                if (gen == my && !pageReady) failNow("پەڕەی Pawan بار نەبوو (ئینتەرنێت یان Cloudflare — «🔑 چوونەژوورەوە» دووبارە بکە)")
                            }, 20_000L)
                        }
                    }
                }
                if (!latch.await(120, TimeUnit.SECONDS)) {
                    ui.post { abort() }
                    throw RuntimeException("Pawan: کاتی چاوەڕوانی تەواو بوو")
                }
                val e1 = err.get()
                if (e1 != null) {
                    // the human check (Cloudflare) / a stale page: reload the page with the saved cookie and try this piece once more
                    if (e1.contains("Cloudflare") && retried < 1) {
                        retried++
                        Bus.say("🔄 Pawan: پەڕەکە دووبارە دەکرێتەوە...")
                        CookieManager.getInstance().flush()
                        reload()
                        Thread.sleep(400)
                        var w8 = 0
                        while (!pageReady && w8 < 150) { Thread.sleep(100); w8++ }
                        Thread.sleep(600)
                        continue
                    }
                    throw RuntimeException("Pawan: $e1")
                }
                idx++
            }
        }
    }

    // ───────────── ڕێکخستنی دەنگ (لە ڕێکخستنەکان؛ دوای کاشکردن جێبەجێ دەکرێت، بۆیە گۆڕین یەکسەر دەردەکەوێت) ─────────────

    private const val TARGET_RMS = 0.1f   // هەمان ئاستی دەنگی Piper

    fun gainPct(): Int = prefs()?.getInt("pw_gain", 100) ?: 100       // ئاستی دەنگ ٣٠..١٥٠٪
    fun ratePct(): Int = prefs()?.getInt("pw_rate", 100) ?: 100       // تۆن/خێرایی ٨٠..١٢٠٪ (بەرز = تیژتر و خێراتر)
    fun softPct(): Int = prefs()?.getInt("pw_soft", 0) ?: 0           // نەرمکردن ٠..١٠٠٪ (کەمکردنەوەی تیژی/«گڕ»ی دەنگ)

    fun resetTuning() {
        prefs()?.edit()?.remove("pw_gain")?.remove("pw_rate")?.remove("pw_soft")?.apply()
    }

    /** PCM16 مۆنۆ 24kHz ← هاوتاکراو: ئاستی یەکسان، نەرمکردن، تۆن/خێرایی، ئاستی دەنگ. */
    fun adjust(pcm: ByteArray): ByteArray {
        val n = pcm.size / 2
        if (n < 2) return pcm
        var x = FloatArray(n) { i -> ((pcm[2 * i].toInt() and 0xFF) or (pcm[2 * i + 1].toInt() shl 8)) / 32768f }
        // ١) ئاستی یەکسان (RMS) — دەنگی Pawan ڕەنگە لە Piper بەرزتر بێت
        var sum = 0.0
        var pk = 0f
        for (v in x) { sum += v.toDouble() * v; val a = Math.abs(v); if (a > pk) pk = a }
        val rms = Math.sqrt(sum / n).toFloat()
        if (rms > 1e-5f && pk > 1e-5f) {
            val g = minOf(TARGET_RMS / rms, 0.95f / pk, 4f)
            for (i in x.indices) x[i] *= g
        }
        // ٢) نەرمکردن: فیلتەری low-pass ی سادە (٠ = هیچ)
        val soft = softPct().coerceIn(0, 100)
        if (soft > 0) {
            val a = 1f - soft / 100f * 0.8f      // 1.0 .. 0.2
            var y = x[0]
            for (i in x.indices) { y += a * (x[i] - y); x[i] = y }
        }
        // ٣) تۆن/خێرایی: ڕێژەی نمونە دەگۆڕێت (بەرزتر = تیژتر و خێراتر)
        val r = ratePct().coerceIn(50, 150) / 100.0
        if (Math.abs(r - 1.0) > 0.001) {
            val m = (x.size / r).toInt().coerceAtLeast(2)
            val z = FloatArray(m)
            for (i in 0 until m) {
                val p = i * r
                val i0 = p.toInt().coerceAtMost(x.size - 1)
                val i1 = (i0 + 1).coerceAtMost(x.size - 1)
                val f = (p - i0).toFloat()
                z[i] = x[i0] * (1 - f) + x[i1] * f
            }
            x = z
        }
        // ٤) ئاستی دەنگ
        val gain = gainPct().coerceIn(10, 200) / 100f
        val out = ByteArray(x.size * 2)
        for (i in x.indices) {
            val s = (x[i] * gain).coerceIn(-1f, 1f).times(32767f).toInt()
            out[2 * i] = (s and 0xFF).toByte()
            out[2 * i + 1] = ((s shr 8) and 0xFF).toByte()
        }
        return out
    }


    // ───────────── live mode: audio is played while it still arrives (outputs other than the media volume) ─────────────

    /** A line that is being made right now: the pieces are queued here and the player takes them one by one. */
    class Live(val text: String) {
        companion object { val END = Any() }
        val epoch = liveEpoch
        private val q = LinkedBlockingQueue<Any>()
        fun put(b: ByteArray) { q.offer(b) }
        fun end() { q.offer(END) }
        fun fail(m: String) { q.offer(m) }
        /** null = nothing yet; END = finished; otherwise a piece of PCM16 mono 24 kHz. Throws when making the line failed. */
        fun poll(ms: Long): Any? {
            val x = q.poll(ms, TimeUnit.MILLISECONDS) ?: return null
            if (x is String) throw RuntimeException(x)
            return x
        }
    }

    private fun floatsOf(b: ByteArray): FloatArray =
        FloatArray(b.size / 2) { i -> ((b[2 * i].toInt() and 0xFF) or (b[2 * i + 1].toInt() shl 8)) / 32768f }

    private fun pcmOf(x: FloatArray, gain: Float): ByteArray {
        val out = ByteArray(x.size * 2)
        for (i in x.indices) {
            val s = (x[i] * gain).coerceIn(-1f, 1f).times(32767f).toInt()
            out[2 * i] = (s and 0xFF).toByte()
            out[2 * i + 1] = ((s shr 8) and 0xFF).toByte()
        }
        return out
    }

    /** Linear resampler that keeps its place between pieces (step = source samples per output sample). */
    private class Resamp(private val step: Double) {
        private var base = 0L
        private var tail = FloatArray(0)
        private var next = 0.0
        fun push(m: FloatArray): FloatArray {
            val arr = if (tail.isEmpty()) m else tail + m
            val last = base + arr.size - 1
            val res = FloatArray((arr.size / step).toInt() + 4)
            var k = 0
            while (true) {
                val i0 = next.toLong()
                if (i0 + 1 > last) break
                val j = (i0 - base).toInt()
                val f = (next - i0).toFloat()
                res[k++] = arr[j] * (1 - f) + arr[j + 1] * f
                next += step
            }
            val keep = (next.toLong() - base).toInt().coerceIn(0, maxOf(0, arr.size - 1))
            tail = arr.copyOfRange(keep, arr.size)
            base += keep
            return res.copyOf(k)
        }
    }

    /** The site's WAV, piece by piece -> PCM16 mono 24 kHz. [bad] = not a plain 16-bit WAV (the caller then decodes the whole file at the end). */
    private class LivePcm(private val out: (ByteArray) -> Unit) {
        var bad = false
        var any = false
        private var started = false
        private var hdr = ByteArray(0)
        private var rate = 24000
        private var ch = 1
        private var bits = 16
        private var fmt = 1
        private var carry = ByteArray(0)
        private var rs: Resamp? = null

        private fun le16(b: ByteArray, o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
        private fun le32(b: ByteArray, o: Int) = le16(b, o) or (le16(b, o + 2) shl 16)

        fun feed(b: ByteArray) {
            if (bad) return
            if (started) { pcm(b); return }
            hdr += b
            if (hdr.size < 12) return
            if (String(hdr, 0, 4, Charsets.ISO_8859_1) != "RIFF" || String(hdr, 8, 4, Charsets.ISO_8859_1) != "WAVE") { bad = true; return }
            var p = 12
            while (true) {
                if (p + 8 > hdr.size) { if (hdr.size > 8192) bad = true; return }
                val id = String(hdr, p, 4, Charsets.ISO_8859_1)
                val len = le32(hdr, p + 4)
                val body = p + 8
                if (id == "data") {
                    if ((fmt != 1 && fmt != 0xFFFE) || bits != 16 || ch < 1) { bad = true; return }
                    started = true
                    if (!(rate == OUT_RATE && ch == 1)) rs = Resamp(rate.toDouble() / OUT_RATE)
                    val rest = hdr.copyOfRange(body, hdr.size)
                    hdr = ByteArray(0)
                    if (rest.isNotEmpty()) pcm(rest)
                    return
                }
                if (id == "fmt ") {
                    if (body + 16 > hdr.size) return
                    fmt = le16(hdr, body); ch = le16(hdr, body + 2); rate = le32(hdr, body + 4); bits = le16(hdr, body + 14)
                }
                if (len < 0) { bad = true; return }
                p = body + len + (len and 1)
            }
        }

        private fun pcm(b: ByteArray) {
            val d = if (carry.isEmpty()) b else carry + b
            val fb = 2 * ch
            val nf = d.size / fb
            carry = d.copyOfRange(nf * fb, d.size)
            if (nf == 0) return
            val r = rs
            if (r == null) {
                any = true
                out(d.copyOfRange(0, nf * 2))
                return
            }
            val m = FloatArray(nf) { i ->
                var sum = 0
                for (c in 0 until ch) {
                    val o = i * fb + 2 * c
                    sum += (d[o].toInt() and 0xFF) or (d[o + 1].toInt() shl 8)
                }
                sum / ch / 32768f
            }
            val y = r.push(m)
            if (y.isNotEmpty()) { any = true; out(pcmOf(y, 1f)) }
        }
    }

    /** The same tuning as [adjust] (equal level, softening, pitch/speed, volume), done piece by piece. */
    private class LiveTune(private val out: (ByteArray) -> Unit) {
        private val soft = softPct().coerceIn(0, 100)
        private val alpha = 1f - soft / 100f * 0.8f
        private val rs: Resamp? = ratePct().coerceIn(50, 150).let { if (Math.abs(it - 100) < 1) null else Resamp(it / 100.0) }
        private val gain = gainPct().coerceIn(10, 200) / 100f
        private var g = 1f
        private var ready = false
        private var held = FloatArray(0)
        private var y = 0f
        private var yInit = false

        fun feed(b: ByteArray) {
            var x = floatsOf(b)
            if (!ready) {
                held += x
                if (held.size < 9600) return      // ~0.4 s: enough to judge the level of this voice
                g = levelOf(held); ready = true; x = held; held = FloatArray(0)
            }
            emit(x)
        }

        fun finish() {
            if (!ready && held.isNotEmpty()) {
                g = levelOf(held); ready = true
                val x = held; held = FloatArray(0)
                emit(x)
            }
        }

        private fun levelOf(x: FloatArray): Float {
            var sum = 0.0
            var pk = 0f
            for (v in x) { sum += v.toDouble() * v; val a = Math.abs(v); if (a > pk) pk = a }
            val rms = Math.sqrt(sum / x.size).toFloat()
            if (rms <= 1e-5f || pk <= 1e-5f) return 1f
            return minOf(TARGET_RMS / rms, 0.95f / pk, 3f)
        }

        private fun emit(x0: FloatArray) {
            var x = x0
            for (i in x.indices) x[i] *= g
            if (soft > 0) {
                for (i in x.indices) {
                    if (!yInit) { y = x[i]; yInit = true }
                    y += alpha * (x[i] - y)
                    x[i] = y
                }
            }
            val r = rs
            if (r != null) x = r.push(x)
            if (x.isEmpty()) return
            out(pcmOf(x, gain))
        }
    }

    private fun requestStream(text: String, chunk: (ByteArray) -> Unit, done: () -> Unit, bad: (String) -> Unit) {
        val a = app ?: run { bad("Pawan ئامادە نەکراوە"); return }
        val my = ++gen
        onAudio = null
        onChunk = chunk
        onDone = done
        onFail = bad
        val w = ensureWeb(a)
        val run = {
            if (gen == my) {
                w.evaluateJavascript(
                    "window.__pawanSpeak(${JSONObject.quote(text)},${JSONObject.quote(voice())},${JSONObject.quote(LANG)},$my,false,1,1,0,true)", null
                )
            }
        }
        if (pageReady) run() else queued = run
    }

    /** One request (<= 300 letters) in live mode: [onPcm] gets raw PCM16 mono 24 kHz pieces while the audio arrives. */
    private fun liveOne(t: String, onPcm: (ByteArray) -> Unit) {
        val latch = CountDownLatch(1)
        val err = AtomicReference<String?>(null)
        val lastAct = AtomicLong(System.currentTimeMillis())
        val full = ByteArrayOutputStream()
        val dec = LivePcm(onPcm)
        ui.post {
            requestStream(t, { b ->
                lastAct.set(System.currentTimeMillis())
                try { full.write(b); dec.feed(b) } catch (e: Throwable) { err.set("دەنگەکە نەکرایەوە (" + e.message + ")"); latch.countDown() }
            }, { latch.countDown() }, { e -> err.set(e); latch.countDown() })
        }
        while (!latch.await(500, TimeUnit.MILLISECONDS)) {
            // no new piece for a long time: give up on this request
            if (System.currentTimeMillis() - lastAct.get() > 20_000L) {
                ui.post { abort() }
                throw RuntimeException("Pawan: کاتی چاوەڕوانی تەواو بوو")
            }
        }
        err.get()?.let { throw RuntimeException("Pawan: $it") }
        if (dec.bad) {
            // not a plain WAV (mp3 / ogg ...): decoded as a whole, at the end
            val raw = full.toByteArray()
            if (raw.isEmpty()) throw RuntimeException("Pawan: دەنگ نەهات")
            try { onPcm(decode(raw)) } catch (e: Throwable) { throw RuntimeException("Pawan: دەنگەکە نەکرایەوە (${e.message})") }
        } else if (!dec.any) {
            throw RuntimeException("Pawan: دەنگ نەهات")
        }
    }

    /**
     * Kurdish text -> speech in live mode: the tuned PCM16 mono 24 kHz pieces go to [sink] while the audio still arrives.
     * Returns the whole RAW (untuned) PCM for the disk cache. Run on a worker thread.
     */
    fun synthLive(text: String, sink: (ByteArray) -> Unit): ByteArray = synchronized(lock) {
        val chunks = chunk(text)
        if (chunks.isEmpty()) throw RuntimeException("دەقەکە بەتاڵە")
        val raw = ByteArrayOutputStream()
        val tune = LiveTune(sink)
        val gap = ByteArray(OUT_RATE / 8 * 2)
        for ((i, c) in chunks.withIndex()) {
            if (i > 0) { raw.write(gap); tune.feed(gap) }
            liveOne(c) { b -> raw.write(b); tune.feed(b) }
        }
        tune.finish()
        raw.toByteArray()
    }

    // ───────────── API ─────────────

    private val lock = Any()

    /** دەقی کوردی ← PCM16 مۆنۆ 24kHz. لەسەر thread ی کار بانگ بکرێت (دەوەستێت تا دەنگەکە دێت). هەڵە = RuntimeException. */
    fun synth(text: String): ByteArray = synchronized(lock) {
        val chunks = chunk(text)
        if (chunks.isEmpty()) throw RuntimeException("دەقەکە بەتاڵە")
        val out = ByteArrayOutputStream()
        val gap = ByteArray(OUT_RATE / 8 * 2)   // ~125ms بێدەنگی لە نێوان بەشەکان
        for ((i, c) in chunks.withIndex()) {
            if (i > 0) out.write(gap)
            out.write(one(c))
        }
        out.toByteArray()
    }

    private fun one(t: String): ByteArray {
        val latch = CountDownLatch(1)
        val bytes = AtomicReference<ByteArray?>(null)
        val err = AtomicReference<String?>(null)
        ui.post {
            request(t, { b -> bytes.set(b); latch.countDown() }, { e -> err.set(e); latch.countDown() })
        }
        if (!latch.await(TIMEOUT_S, TimeUnit.SECONDS)) {
            ui.post { abort() }
            throw RuntimeException("Pawan: کاتی چاوەڕوانی تەواو بوو")
        }
        err.get()?.let { throw RuntimeException("Pawan: $it") }
        val raw = bytes.get() ?: throw RuntimeException("Pawan: دەنگ نەهات")
        return try {
            decode(raw)
        } catch (e: Throwable) {
            Log.e(TAG, "decode failed", e)
            throw RuntimeException("Pawan: دەنگەکە نەکرایەوە (${e.message})")
        }
    }

    /** دەق دابەش دەکات بۆ ڕستە و بەشی تا ٣٠٠ پیت. */
    private fun chunk(s: String): List<String> {
        val sentences = s.trim().split(Regex("(?<=[.!?؟\\n])\\s*")).map { it.trim() }.filter { it.isNotEmpty() }
        val res = ArrayList<String>()
        val cur = StringBuilder()
        for (x in sentences) {
            if (cur.isNotEmpty() && cur.length + x.length + 1 > MAX_CHUNK) { res.add(cur.toString()); cur.setLength(0) }
            if (x.length > MAX_CHUNK) {
                // ڕستەی زۆر درێژ: لە نزیکترین بۆشاییەوە دەیبڕێت
                var rest = x
                while (rest.length > MAX_CHUNK) {
                    val cut = rest.lastIndexOf(' ', MAX_CHUNK).let { if (it < 50) MAX_CHUNK else it }
                    res.add(rest.substring(0, cut).trim())
                    rest = rest.substring(cut).trim()
                }
                if (rest.isNotEmpty()) cur.append(rest)
            } else {
                if (cur.isNotEmpty()) cur.append(' ')
                cur.append(x)
            }
        }
        if (cur.isNotEmpty()) res.add(cur.toString())
        return res
    }

    // ───────────── دیکۆدکردن: هەر فۆرماتێک (wav / mp3 / ogg / m4a ...) ← PCM16 مۆنۆ 24kHz ─────────────

    private fun decode(b: ByteArray): ByteArray {
        wav(b)?.let { return it }
        val f = File.createTempFile("pawan", ".bin", app!!.cacheDir)
        try {
            f.writeBytes(b)
            return viaCodec(f)
        } finally {
            f.delete()
        }
    }

    private fun le16(b: ByteArray, o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
    private fun le32(b: ByteArray, o: Int) = le16(b, o) or (le16(b, o + 2) shl 16)

    /** WAV ی PCM16 ڕاستەوخۆ دەخوێنرێتەوە؛ null ئەگەر WAV ی ئاسایی نەبوو. */
    private fun wav(b: ByteArray): ByteArray? {
        if (b.size < 44 || String(b, 0, 4, Charsets.ISO_8859_1) != "RIFF" || String(b, 8, 4, Charsets.ISO_8859_1) != "WAVE") return null
        var p = 12
        var ch = 1; var rate = 24000; var bits = 16; var fmt = 1
        while (p + 8 <= b.size) {
            val id = String(b, p, 4, Charsets.ISO_8859_1)
            var len = le32(b, p + 4)
            val body = p + 8
            if (id == "fmt " && body + 16 <= b.size) {
                fmt = le16(b, body); ch = le16(b, body + 2); rate = le32(b, body + 4); bits = le16(b, body + 14)
            } else if (id == "data") {
                if (len < 0 || body + len > b.size) len = b.size - body   // پەخشی زیندوو: درێژی نادروستە
                if ((fmt != 1 && fmt != 0xFFFE) || bits != 16 || ch < 1) return null
                return to24kMono(b, body, len, rate, ch)
            }
            if (len < 0) return null
            p = body + len + (len and 1)
        }
        return null
    }

    private fun viaCodec(f: File): ByteArray {
        val ex = MediaExtractor()
        ex.setDataSource(f.absolutePath)
        var track = -1
        var mime = ""
        for (i in 0 until ex.trackCount) {
            val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (m.startsWith("audio/")) { track = i; mime = m; break }
        }
        if (track < 0) { ex.release(); throw RuntimeException("فایلی دەنگ نییە") }
        ex.selectTrack(track)
        val fmt = ex.getTrackFormat(track)
        var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(fmt, null, null, 0)
        codec.start()
        val pcm = ByteArrayOutputStream()
        val info = MediaCodec.BufferInfo()
        var inDone = false
        var outDone = false
        val deadline = System.currentTimeMillis() + 20_000
        try {
            while (!outDone && System.currentTimeMillis() < deadline) {
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    oi >= 0 -> {
                        val ob = codec.getOutputBuffer(oi)!!
                        val chunk = ByteArray(info.size)
                        ob.position(info.offset)
                        ob.get(chunk)
                        pcm.write(chunk)
                        codec.releaseOutputBuffer(oi, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                    }
                    oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val of = codec.outputFormat
                        rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                }
            }
        } finally {
            try { codec.stop() } catch (_: Throwable) {}
            codec.release()
            ex.release()
        }
        val all = pcm.toByteArray()
        if (all.isEmpty()) throw RuntimeException("دەنگەکە بەتاڵ بوو")
        return to24kMono(all, 0, all.size, rate, ch)
    }

    /** PCM16 (چەند کەناڵ، هەر ڕێژەیەک) ← مۆنۆ 24kHz بە لێکدانی هێڵی. */
    private fun to24kMono(b: ByteArray, off: Int, len: Int, rate: Int, ch: Int): ByteArray {
        val frames = len / (2 * ch)
        if (frames <= 0) throw RuntimeException("دەنگەکە بەتاڵ بوو")
        val mono = FloatArray(frames)
        for (i in 0 until frames) {
            var s = 0
            for (c in 0 until ch) {
                val o = off + (i * ch + c) * 2
                s += (b[o].toInt() and 0xFF) or (b[o + 1].toInt() shl 8)   // b[o+1] واژۆ دەکرێت = signed 16
            }
            mono[i] = s / ch / 32768f
        }
        val n = if (rate == OUT_RATE) frames else (frames.toLong() * OUT_RATE / rate).toInt()
        val out = ByteArray(n * 2)
        val step = rate.toDouble() / OUT_RATE
        for (i in 0 until n) {
            val p = i * step
            val i0 = p.toInt().coerceAtMost(frames - 1)
            val i1 = (i0 + 1).coerceAtMost(frames - 1)
            val fr = (p - i0).toFloat()
            val v = (mono[i0] * (1 - fr) + mono[i1] * fr).coerceIn(-1f, 1f)
            val s = (v * 32767f).toInt()
            out[2 * i] = (s and 0xFF).toByte()
            out[2 * i + 1] = ((s shr 8) and 0xFF).toByte()
        }
        return out
    }

    // ───────────── JavaScript ی ناو ماڵپەڕەکە ─────────────

    private const val HOOK_JS = """
(function(){
  if (window.__pawanHooked) return; window.__pawanHooked = true;
  window.__tok = 0; window.__sent = 0;
  function send(buf){
    if (!window.__tok || window.__sent === window.__tok) return;
    window.__sent = window.__tok;
    var u8 = new Uint8Array(buf), s = '', CH = 0x8000;
    for (var i = 0; i < u8.length; i += CH) s += String.fromCharCode.apply(null, u8.subarray(i, i + CH));
    AndroidTts.audio(window.__tok, btoa(s));
  }
  function b64(u8){ var s = '', CH = 0x8000; for (var i = 0; i < u8.length; i += CH) s += String.fromCharCode.apply(null, u8.subarray(i, i + CH)); return btoa(s); }
  // live mode: the audio is handed on piece by piece while it arrives, so playing can start at once
  function streamResp(r, tk){
    if (window.__sent === tk) return Promise.resolve();
    window.__sent = tk;
    var rd = r.body.getReader();
    var pump = function(){
      return rd.read().then(function(x){
        if (window.__tok !== tk) { try { rd.cancel(); } catch (e) {} return; }
        if (x.done) { AndroidTts.sdone(tk); return; }
        if (x.value && x.value.length) AndroidTts.chunk(tk, b64(x.value));
        return pump();
      });
    };
    return pump().catch(function(e){ AndroidTts.failed(tk, 'stream: ' + e); });
  }
  // هەر دەنگێک ماڵپەڕەکە بە fetch دەیهێنێت (دەنگی دروستکراو /api/takes/.../audio) وەردەگیرێت
  var of = window.fetch;
  window.fetch = function(){
    var p = of.apply(this, arguments);
    try {
      var u = arguments[0]; u = (typeof u === 'string') ? u : ((u && u.url) || '');
      p.then(function(r){
        try {
          var ct = r.headers.get('content-type') || '';
          if (window.__tok && window.__dbg && window.__dbg.length < 12) window.__dbg.push('fetch:' + ct.substring(0, 20) + ':' + u.substring(0, 40));
          if (window.__direct && window.__tok && (ct.indexOf('audio/') === 0 || /\/api\/takes\//.test(u))) window.__pwPlayed = window.__tok;
          if (window.__tok && !window.__direct && window.__sent !== window.__tok &&
              (ct.indexOf('audio/') === 0 || /\/api\/takes\/[^\/]+\/audio/.test(u)))
            { if (window.__stream && r.body && r.body.getReader) streamResp(r.clone(), window.__tok); else r.clone().arrayBuffer().then(send).catch(function(){}); }
        } catch (e) {}
      }).catch(function(){});
    } catch (e) {}
    return p;
  };
  // ئەگەر بە <audio> پەخش کرا: بێدەنگی بکە و src ـەکەی بهێنە (src دوای play() دێت، بۆیە چەند جار دووبارە دەکرێتەوە)
  window.__dbg = [];
  function dbg(x){ try { if (window.__dbg.length < 12) window.__dbg.push(x); } catch (e) {} }
  var P = HTMLMediaElement.prototype, origPlay = P.play;
  P.play = function(){
    var a = this;
    if (window.__direct) {
      // دۆخی ڕاستەوخۆ (وەک مانگا): ماڵپەڕەکە خۆی دەنگەکە دەپەخشێنێت؛ تەنها ڕێکخستنی دەنگ و ئاگاداری کۆتایی
      try {
        var c = window.__pwCfg || {g: 1, r: 1, s: 0};
        window.__pwPlayed = window.__tok;
        a.muted = false; a.volume = Math.min(1, c.g);
        a.preservesPitch = false; a.webkitPreservesPitch = false; a.mozPreservesPitch = false;
        a.playbackRate = c.r;
        var freq = c.s > 0 ? (12000 - c.s / 100 * 9000) : 22000;
        if (a.__flt) { a.__flt.frequency.value = freq; }
        else if (c.s > 0) {
          var AC = window.AudioContext || window.webkitAudioContext;
          var cx = window.__pwCtx || (window.__pwCtx = new AC());
          var src0 = cx.createMediaElementSource(a), f = cx.createBiquadFilter();
          f.type = 'lowpass'; f.frequency.value = freq;
          src0.connect(f); f.connect(cx.destination);
          a.__flt = f;
          if (cx.resume) cx.resume();
        }
      } catch (e) {}
      if (!a.__h) { a.__h = 1;
        a.addEventListener('ended', function(){ if (window.__direct && window.__tok && window.__sent !== window.__tok) { window.__sent = window.__tok; AndroidTts.ended(window.__tok); } });
        a.addEventListener('error', function(){ if (window.__direct && window.__tok) AndroidTts.failed(window.__tok, 'دەنگەکە پەخش نەکرا'); });
      }
      return origPlay.apply(this, arguments);
    }
    try { a.muted = true; a.volume = 0; } catch (e) {}
    var tok = window.__tok;
    if (tok && window.__sent !== tok) {
      var tries = 0;
      var tick = function(){
        if (window.__sent === tok || window.__tok !== tok) return;
        var src = a.currentSrc || a.src || '';
        if (tries === 0) dbg('play:' + src.substring(0, 60));
        if (src && src.indexOf('mediasource') < 0) {
          of.call(window, src, {credentials: 'include'})
            .then(function(r){ if (!r.ok) throw new Error('http' + r.status); if (window.__stream && r.body && r.body.getReader && window.__tok === tok) return streamResp(r, tok); return r.arrayBuffer().then(send); })
            .catch(function(e){ if (++tries < 8) setTimeout(tick, 500); else dbg('fetchsrc:' + e); });
        } else if (++tries < 12) setTimeout(tick, 250);
      };
      setTimeout(tick, 150);
    }
    return origPlay.apply(this, arguments);
  };
  // دەنگی Blob (URL.createObjectURL) و decodeAudioData ـیش وەردەگیرێن
  try {
    var oco = URL.createObjectURL;
    URL.createObjectURL = function(o){
      try {
        if (o && o.type && o.type.indexOf('audio') === 0 && window.__tok && window.__sent !== window.__tok) {
          dbg('blob:' + o.type);
          o.arrayBuffer().then(send).catch(function(){});
        }
      } catch (e) {}
      return oco.apply(this, arguments);
    };
  } catch (e) {}
  try {
    var AC0 = window.AudioContext || window.webkitAudioContext;
    var oda = AC0.prototype.decodeAudioData;
    AC0.prototype.decodeAudioData = function(buf){
      try { if (window.__tok && window.__sent !== window.__tok) { dbg('decode'); send(buf.slice(0)); } } catch (e) {}
      return oda.apply(this, arguments);
    };
  } catch (e) {}
  // Web Audio ـیش هیچ دەنگێک نەداتە بلندگۆ (analyser بۆ ڕووکارەکە دەمێنێت)
  try {
    var oc = AudioNode.prototype.connect;
    AudioNode.prototype.connect = function(d){
      if (!window.__direct && typeof AudioDestinationNode !== 'undefined' && d instanceof AudioDestinationNode) return d;
      return oc.apply(this, arguments);
    };
  } catch (e) {}

  window.__pawanStop = function(){
    clearInterval(window.__pawanIv);
    var b = document.getElementById('speak');
    if (b && b.hasAttribute('data-busy')) b.click();
    document.querySelectorAll('audio').forEach(function(a){ try { a.pause(); } catch (e) {} });
  };

  window.__pawanSpeak = function(text, voice, lang, tok, direct, g, r, sf, stream){
    window.__tok = tok;
    window.__stream = !!stream;
    window.__direct = !!direct;
    window.__pwCfg = {g: g == null ? 1 : g, r: r == null ? 1 : r, s: sf || 0};
    var t = document.getElementById('text'), b = document.getElementById('speak');
    if (!t || !b) { AndroidTts.failed(tok, 'پشتڕاستکردنەوەی مرۆڤ (Cloudflare) پێویستە یان بەسەرچووە — لە ڕێکخستنەکان «🔑 چوونەژوورەوە بۆ Pawan TTS» بگرە و پشتڕاستی بکەرەوە'); return; }
    clearInterval(window.__pawanIv);
    document.querySelectorAll('audio').forEach(function(a){ try { a.pause(); } catch (e) {} });
    var busy = function(){ return b.hasAttribute('data-busy'); };
    var pick = function(sel){
      var e = document.querySelector(sel);
      if (e && e.getAttribute('aria-checked') !== 'true') { e.click(); return true; }
      return false;
    };
    var go = function(){
      var changed = pick('#langs [data-lang="' + lang + '"]');
      changed = pick('#voices .voice[data-voice="' + voice + '"]') || changed;
      setTimeout(function(){
        var setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
        setter.call(t, text);
        t.dispatchEvent(new Event('input', {bubbles: true}));
        setTimeout(function(){
          b.click();
          var n = 0;
          var seen = false;
          window.__pawanIv = setInterval(function(){
            n++;
            if (window.__sent === tok) { clearInterval(window.__pawanIv); return; }
            if (window.__direct) {
              // پاڵپشت: ئەگەر پێوەرەکانی ended نەهاتن، لە دۆخی busy/audio تێدەگەین
              var playing = false;
              document.querySelectorAll('audio').forEach(function(a){ if (!a.paused && !a.ended) playing = true; });
              if (b.hasAttribute('data-busy') || playing || window.__pwPlayed === tok) seen = true;
              else if (!seen && n > 180) { clearInterval(window.__pawanIv); AndroidTts.failed(tok, 'ماڵپەڕەکە دەستی بە خوێندنەوە نەکرد (دوگمەکە کارینەکرد، لەوانەیە Cloudflare بێت)'); return; }
              else if (seen) { clearInterval(window.__pawanIv); window.__sent = tok; AndroidTts.ended(tok); return; }
            }
            var er = document.getElementById('error');
            if (er && !er.hidden && er.textContent.trim()) {
              clearInterval(window.__pawanIv);
              AndroidTts.failed(tok, er.textContent.trim().substring(0, 120));
            } else if (n > (window.__direct ? 1200 : 510)) { clearInterval(window.__pawanIv); AndroidTts.failed(tok, 'دەنگەکە نەگەیشت [' + (window.__dbg || []).join(' | ') + ']'); }
          }, 100);
        }, 20);
      }, changed ? 80 : 0);
    };
    if (busy()) {
      b.click();
      var w = 0, iv = setInterval(function(){ if (!busy() || ++w > 20) { clearInterval(iv); go(); } }, 50);
    } else go();
  };
})();
"""
}
