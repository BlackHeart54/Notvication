package com.hardi.kurdishtranslator

import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * داگرتنی بەردەوام: ئەگەر ئینتەرنێت پچڕا یان ئەپەکە داخرا، فایلە نیوەچڵەکە (.part) دەمێنێتەوە
 * و جاری داهاتوو لەو شوێنەوە بەردەوام دەبێت (HTTP Range) نەک لە سفرەوە.
 */
object Downloader {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    /** true = هەڵەکە هەمیشەییە (وەک لینکی 404)، دووبارەهەوڵدانەوە سوودی نییە. */
    @Volatile var permanent = false

    /** فۆڵدەری فایلە نیوەچڵەکان — لە filesDir دایە (نەک cache) بۆ ئەوەی سیستەم نەیسڕێتەوە. */
    fun dir(filesDir: File) = File(filesDir, "dl").apply { mkdirs() }

    /**
     * [url] دادەگرێت بۆ [part]؛ ئەگەر [part] پێشتر هەبوو لەو شوێنەوە بەردەوام دەبێت.
     * null = تەواو بوو، ئەگینا پەیامی هەڵە (فایلە نیوەچڵەکە دەمێنێتەوە بۆ جاری داهاتوو).
     */
    fun fetch(part: File, url: String, progress: (Int) -> Unit): String? {
        permanent = false
        part.parentFile?.mkdirs()
        val have0 = if (part.exists()) part.length() else 0L
        val rb = Request.Builder().url(url)
        if (have0 > 0) rb.header("Range", "bytes=$have0-")
        return try {
            http.newCall(rb.build()).execute().use { r ->
                if (r.code == 416) {          // فایلەکە هەڵەیە/تەواوبووە بەڵام نازانرێت: لە سفرەوە
                    part.delete()
                    return "داگرتن دەستپێدەکاتەوە"
                }
                if (!r.isSuccessful) {
                    permanent = r.code in 400..499 && r.code != 408 && r.code != 429
                    return "داگرتن سەرنەکەوت: HTTP " + r.code
                }
                val body = r.body ?: return "وەڵامی بەتاڵ"
                val resumed = r.code == 206
                val have = if (resumed) have0 else 0L     // 200 = سێرڤەر Range ی قبوڵ نەکرد، لە سفرەوە
                val len = body.contentLength()
                val total = if (len > 0) len + have else -1L
                var got = have
                var last = -1
                FileOutputStream(part, resumed).use { out ->
                    body.byteStream().use { ins ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            got += n
                            if (total > 0) {
                                val p = (got * 100 / total).toInt()
                                if (p != last) { last = p; progress(p) }
                            }
                        }
                    }
                }
                if (total > 0 && got < total) return "ئینتەرنێت پچڕا ($got / $total)"
            }
            null
        } catch (e: IOException) {
            "ئینتەرنێت پچڕا: ${e.message}"
        }
    }
}
