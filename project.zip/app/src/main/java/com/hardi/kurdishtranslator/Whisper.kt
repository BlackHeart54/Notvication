package com.hardi.kurdishtranslator

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.FloatBuffer
import java.nio.LongBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * ناسینەوەی قسەی ئینگلیزی بە Whisper base.en (ONNX) — ئۆفلاین، دوای یەکەم داگرتن.
 *
 * دوو جۆری مۆدێل هەیە (بەکارهێنەر هەڵیدەبژێرێت):
 *   - "quantized"  (نزیکەی ٧٧MB)
 *   - "uint8"      (نزیکەی ١٨٣MB)
 *
 * فایلەکان لە GitHub Release دادەبەزن (ناوەکان وەک خۆیان):
 *   vocab.json
 *   encoder_model_quantized.onnx   decoder_model_quantized.onnx
 *   encoder_model_uint8.onnx       decoder_model_uint8.onnx
 *
 * پایپلاین: PCM 16k mono → log-mel (80×3000) → encoder → decoder (greedy) → دەق.
 * tokenizer تەنها بۆ گەڕانەوەی ژمارەکان بۆ دەق پێویستە، بۆیە vocab.json بەس.
 */
object Whisper {
    private const val TAG = "Whisper"

    const val V_Q = "quantized"
    const val V_U = "uint8"

    // ---- audio / model constants (whisper-base.en)
    private const val NFFT = 400
    private const val HOP = 160
    private const val NMEL = 80
    private const val NBIN = NFFT / 2 + 1      // 201
    private const val NSAMP = 480000           // 30 s @ 16 kHz
    private const val NFRAMES = 3000           // the encoder only accepts exactly 30 s
    private const val N_VOCAB = 51864
    private const val SOT = 50257              // <|startoftranscript|>
    private const val NOTS = 50362             // <|notimestamps|>  (forced after SOT for the .en model)
    private const val EOT = 50256              // <|endoftext|>
    private const val N_TEXT = 50257           // ids below this are real text tokens (+ EOT)
    private const val MAX_NEW = 120

    // tokens Whisper never emits (from config.json "suppress_tokens"; the ones >= 50257 are excluded by N_TEXT)
    private val suppressIds = intArrayOf(
        1, 2, 7, 8, 9, 10, 14, 25, 26, 27, 28, 29, 31, 58, 59, 60, 61, 62, 63, 90, 91, 92, 93, 357, 366, 438, 532,
        685, 705, 796, 930, 1058, 1220, 1267, 1279, 1303, 1343, 1377, 1391, 1635, 1782, 1875, 2162, 2361, 2488, 3467,
        4008, 4211, 4600, 4808, 5299, 5855, 6329, 7203, 9609, 9959, 10563, 10786, 11420, 11709, 11907, 13163, 13697,
        13700, 14808, 15306, 16410, 16791, 17992, 19203, 19510, 20724, 22305, 22935, 27007, 30109, 30420, 33409,
        34949, 40283, 40493, 40549, 47282, 49146
    )
    private val suppressed = BooleanArray(N_TEXT).also { a -> for (i in suppressIds) if (i < N_TEXT) a[i] = true }

    // ---------------------------------------------------------------- files

    fun dir(filesDir: File) = File(filesDir, "whisper_en")
    private fun vocabFile(filesDir: File) = File(dir(filesDir), "vocab.json")
    private fun encFile(filesDir: File, v: String) = File(File(dir(filesDir), v), "encoder.onnx")
    private fun decFile(filesDir: File, v: String) = File(File(dir(filesDir), v), "decoder.onnx")

    // smaller than any real file, so a truncated / error-page download is rejected
    private const val VOCAB_MIN = 500_000L
    private const val ENC_MIN = 15_000_000L
    private const val DEC_MIN = 40_000_000L

    fun isInstalled(filesDir: File, v: String): Boolean =
        vocabFile(filesDir).length() >= VOCAB_MIN &&
            encFile(filesDir, v).length() >= ENC_MIN &&
            decFile(filesDir, v).length() >= DEC_MIN

    /** Approximate download size, only for showing to the user. */
    fun sizeText(v: String) = if (v == V_U) "≈183MB" else "≈77MB"

    // ---------------------------------------------------------------- download

    /**
     * Downloads vocab.json + encoder + decoder of variant [v] from [base] (a GitHub Release folder URL).
     * Every file resumes after a network drop (Downloader). null = ok, otherwise an error message.
     * Call on a worker thread.
     */
    fun download(filesDir: File, v: String, base: String, progress: (Int) -> Unit): String? {
        reset()
        val b = base.trim().let { if (it.endsWith("/")) it else "$it/" }
        if (!b.startsWith("http")) return "لینکی Release دروست نییە (دەبێت https://... بێت)"

        class Item(val remote: String, val dest: File, val min: Long, val weight: Int)

        val items = listOf(
            Item("vocab.json", vocabFile(filesDir), VOCAB_MIN, 1),
            Item("encoder_model_$v.onnx", encFile(filesDir, v), ENC_MIN, 23),
            Item("decoder_model_$v.onnx", decFile(filesDir, v), DEC_MIN, if (v == V_U) 160 else 54)
        )
        val total = items.sumOf { it.weight }
        var done = 0
        val dl = Downloader.dir(filesDir)
        for (item in items) {
            if (item.dest.length() >= item.min) {            // already downloaded earlier
                done += item.weight
                progress(done * 100 / total)
                continue
            }
            val part = File(dl, "wh_${v}_${item.remote}.part")
            val done0 = done
            Downloader.fetch(part, b + item.remote) { p ->
                progress((done0 + item.weight * p / 100) * 100 / total)
            }?.let { e -> return "${item.remote}: $e" }
            if (part.length() < item.min) {
                part.delete()
                return "${item.remote}: فایلەکە ناتەواوە یان هەڵەیە — ناوی فایل و Release بپشکنە"
            }
            item.dest.parentFile?.mkdirs()
            item.dest.delete()
            if (!part.renameTo(item.dest)) {
                try {
                    part.copyTo(item.dest, overwrite = true)
                    part.delete()
                } catch (e: Throwable) {
                    return "نەتوانرا ${item.remote} دابنرێت: ${e.message}"
                }
            }
            done += item.weight
            progress(done * 100 / total)
        }
        return null
    }

    // ---------------------------------------------------------------- import (files already on the phone)

    private fun nameOf(ctx: Context, uri: Uri): String =
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        } catch (_: Exception) { null } ?: uri.lastPathSegment.orEmpty()

    /** Where a file goes, by its name. null = not a Whisper file we use. Sets [touched] to the variant it belongs to. */
    private fun route(filesDir: File, name: String, selected: String, touched: MutableSet<String>): File? {
        val n = name.substringAfterLast('/').lowercase()
        if (n == "vocab.json") return vocabFile(filesDir)
        if (!n.endsWith(".onnx") || "with_past" in n || "merged" in n) return null
        val v = when {
            "uint8" in n -> V_U
            "quantized" in n -> V_Q
            else -> selected
        }
        return when {
            "encoder" in n -> { touched.add(v); encFile(filesDir, v) }
            "decoder" in n -> { touched.add(v); decFile(filesDir, v) }
            else -> null
        }
    }

    private fun put(dest: File, ins: java.io.InputStream) {
        dest.parentFile?.mkdirs()
        val tmp = File(dest.parentFile, dest.name + ".tmp")
        tmp.outputStream().use { ins.copyTo(it) }
        dest.delete()
        if (!tmp.renameTo(dest)) { tmp.delete(); throw RuntimeException("نەتوانرا فایلەکە دابنرێت") }
    }

    /**
     * Imports Whisper files chosen by the user: encoder_model_*.onnx, decoder_model_*.onnx and vocab.json
     * (several files at once, or a zip holding them). The variant (quantized / uint8) comes from the file name;
     * a name without either uses [selected]. null = ok, otherwise an error message. Call on a worker thread.
     */
    fun importFiles(ctx: Context, uris: List<Uri>, selected: String): String? {
        reset()
        val fd = ctx.filesDir
        val touched = LinkedHashSet<String>()
        var used = 0
        try {
            for (u in uris) {
                val name = nameOf(ctx, u)
                val ins = ctx.contentResolver.openInputStream(u) ?: return "فایلەکە نەکرایەوە ($name)"
                ins.use {
                    if (name.lowercase().endsWith(".zip")) {
                        java.util.zip.ZipInputStream(it.buffered()).use { zin ->
                            while (true) {
                                val en = zin.nextEntry ?: break
                                if (en.isDirectory) continue
                                val dest = route(fd, en.name, selected, touched) ?: continue
                                put(dest, zin)
                                used++
                            }
                        }
                    } else {
                        val dest = route(fd, name, selected, touched)
                        if (dest != null) { put(dest, it); used++ }
                    }
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "import failed", e)
            return "هێنان سەرنەکەوت: ${e.message}"
        }
        if (used == 0) return "هیچ فایلێکی Whisper نەدۆزرایەوە (encoder_model_*.onnx، decoder_model_*.onnx، vocab.json)"
        if (touched.any { isInstalled(fd, it) }) return null
        val v = touched.firstOrNull() ?: selected
        val miss = ArrayList<String>()
        if (vocabFile(fd).length() < VOCAB_MIN) miss.add("vocab.json")
        if (encFile(fd, v).length() < ENC_MIN) miss.add("encoder_model_$v.onnx")
        if (decFile(fd, v).length() < DEC_MIN) miss.add("decoder_model_$v.onnx")
        return "هێشتا ئەمانە کەمن: " + miss.joinToString("، ")
    }

    /** Deletes one variant (the models are big). vocab.json goes too when no variant is left. */
    fun delete(filesDir: File, v: String) {
        reset()
        File(dir(filesDir), v).deleteRecursively()
        if (!isInstalled(filesDir, V_Q) && !isInstalled(filesDir, V_U)) {
            // nothing usable left: remove the rest as well
            dir(filesDir).deleteRecursively()
        }
    }

    // ---------------------------------------------------------------- engine

    private class Engine(
        val variant: String,
        val env: OrtEnvironment,
        val enc: OrtSession,
        val dec: OrtSession,
        val vocab: Array<String?>
    )

    @Volatile private var engine: Engine? = null
    private val lock = Any()

    fun reset() {
        synchronized(lock) {
            engine?.let {
                try { it.enc.close() } catch (_: Throwable) {}
                try { it.dec.close() } catch (_: Throwable) {}
            }
            engine = null
        }
    }

    /** Loads the models once (a few seconds the first time). Throws a readable error. */
    fun load(filesDir: File, v: String) {
        loadEngine(filesDir, v)
    }

    private fun loadEngine(filesDir: File, v: String): Engine {
        val cur = engine
        if (cur != null && cur.variant == v) return cur
        return synchronized(lock) {
            val again = engine
            if (again != null && again.variant == v) {
                again
            } else {
                reset()
                if (!isInstalled(filesDir, v)) throw RuntimeException("مۆدێلی Whisper ($v) نەهێنراوە")
                try {
                    val env = OrtEnvironment.getEnvironment()
                    val cores = Runtime.getRuntime().availableProcessors()
                    val threads = min(4, max(2, cores / 2))
                    val opts = OrtSession.SessionOptions().apply { setIntraOpNumThreads(threads) }
                    val enc = env.createSession(encFile(filesDir, v).absolutePath, opts)
                    val dec = env.createSession(decFile(filesDir, v).absolutePath, opts)
                    val vocab = readVocab(vocabFile(filesDir))
                    val e = Engine(v, env, enc, dec, vocab)
                    engine = e
                    e
                } catch (t: Throwable) {
                    Log.e(TAG, "load failed", t)
                    reset()
                    throw RuntimeException("مۆدێلی Whisper نەکرایەوە: " + (t.message ?: t.toString()).take(120))
                }
            }
        }
    }

    private fun readVocab(f: File): Array<String?> {
        val js = JSONObject(f.readText())
        val arr = arrayOfNulls<String>(N_VOCAB)
        val keys = js.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val id = js.getInt(k)
            if (id in 0 until N_VOCAB) arr[id] = k
        }
        return arr
    }

    // ---------------------------------------------------------------- tokenizer (decode only)

    // GPT-2 byte-level BPE: every visible char in a token stands for one byte
    private val byteDec: Map<Char, Int> by lazy {
        val bs = ArrayList<Int>()
        for (b in 33..126) bs.add(b)
        for (b in 161..172) bs.add(b)
        for (b in 174..255) bs.add(b)
        val cs = ArrayList<Int>(bs)
        var n = 0
        for (b in 0..255) {
            if (!bs.contains(b)) {
                bs.add(b)
                cs.add(256 + n)
                n++
            }
        }
        val m = HashMap<Char, Int>()
        for (i in bs.indices) m[cs[i].toChar()] = bs[i]
        m
    }

    private fun detok(e: Engine, ids: List<Int>): String {
        val out = ByteArrayOutputStream()
        for (id in ids) {
            val t = e.vocab.getOrNull(id) ?: continue
            for (ch in t) {
                val b = byteDec[ch]
                if (b != null) out.write(b)
            }
        }
        return String(out.toByteArray(), Charsets.UTF_8)
    }

    // ---------------------------------------------------------------- log-mel (same as WhisperFeatureExtractor)

    private val window = FloatArray(NFFT) { (0.5 - 0.5 * cos(2.0 * PI * it / NFFT)).toFloat() }   // periodic Hann

    private val cosT: FloatArray by lazy {
        FloatArray(NBIN * NFFT) { cos(2.0 * PI * ((it / NFFT).toLong() * (it % NFFT) % NFFT) / NFFT).toFloat() }
    }
    private val sinT: FloatArray by lazy {
        FloatArray(NBIN * NFFT) { sin(2.0 * PI * ((it / NFFT).toLong() * (it % NFFT) % NFFT) / NFFT).toFloat() }
    }

    private fun hzToMel(f: Double): Double {
        val fsp = 200.0 / 3
        val minLogMel = 1000.0 / fsp
        val logStep = ln(6.4) / 27.0
        return if (f >= 1000.0) minLogMel + ln(f / 1000.0) / logStep else f / fsp
    }

    private fun melToHz(m: Double): Double {
        val fsp = 200.0 / 3
        val minLogMel = 1000.0 / fsp
        val logStep = ln(6.4) / 27.0
        return if (m >= minLogMel) 1000.0 * exp(logStep * (m - minLogMel)) else m * fsp
    }

    private class Fb(val start: IntArray, val w: Array<FloatArray>)

    // Slaney mel filter bank (80 filters, 0-8000 Hz), stored sparsely
    private val fb: Fb by lazy {
        val hz = DoubleArray(NMEL + 2)
        val m0 = hzToMel(0.0)
        val m1 = hzToMel(8000.0)
        for (i in hz.indices) hz[i] = melToHz(m0 + (m1 - m0) * i / (NMEL + 1))
        val starts = IntArray(NMEL)
        val ws = Array(NMEL) { FloatArray(0) }
        for (i in 0 until NMEL) {
            val full = DoubleArray(NBIN)
            var first = -1
            var last = -1
            for (k in 0 until NBIN) {
                val f = 8000.0 * k / (NBIN - 1)
                val lo = (f - hz[i]) / (hz[i + 1] - hz[i])
                val up = (hz[i + 2] - f) / (hz[i + 2] - hz[i + 1])
                val v = max(0.0, min(lo, up)) * (2.0 / (hz[i + 2] - hz[i]))
                full[k] = v
                if (v > 0.0) {
                    if (first < 0) first = k
                    last = k
                }
            }
            if (first < 0) { first = 0; last = 0 }
            starts[i] = first
            ws[i] = FloatArray(last - first + 1) { full[first + it].toFloat() }
        }
        Fb(starts, ws)
    }

    /**
     * 16 kHz mono PCM → [80 × 3000] log-mel (row-major, mel first).
     * Only the frames that really contain audio are computed; the zero padding up to 30 s gives a constant -10
     * before normalisation, exactly as the full computation would.
     */
    private fun logMel(pcm: ShortArray): FloatArray {
        val n = min(pcm.size, NSAMP)
        val nReal = min(NFRAMES, (n + NFFT / 2) / HOP + 1)
        val out = FloatArray(NMEL * NFRAMES)
        java.util.Arrays.fill(out, -10f)

        // signal with 200 samples of reflection on the left (center=True) and zeros after the audio
        val len = (nReal - 1) * HOP + NFFT
        val pad = FloatArray(len)
        for (i in 0 until len) {
            val j = i - NFFT / 2
            val idx = if (j < 0) -j else j
            pad[i] = if (idx < n) pcm[idx] / 32768f else 0f
        }

        val ct = cosT
        val sn = sinT
        val x = FloatArray(NFFT)
        val power = FloatArray(NBIN)
        var mx = if (nReal < NFRAMES) -10f else -Float.MAX_VALUE
        val bank = fb
        for (t in 0 until nReal) {
            val off = t * HOP
            for (i in 0 until NFFT) x[i] = pad[off + i] * window[i]
            for (k in 0 until NBIN) {
                var re = 0f
                var im = 0f
                val base = k * NFFT
                for (i in 0 until NFFT) {
                    val xv = x[i]
                    re += xv * ct[base + i]
                    im += xv * sn[base + i]
                }
                power[k] = re * re + im * im
            }
            for (m in 0 until NMEL) {
                val w = bank.w[m]
                val first = bank.start[m]
                var s = 0f
                for (j in w.indices) s += w[j] * power[first + j]
                val lv = log10(max(s, 1e-10f).toDouble()).toFloat()
                out[m * NFRAMES + t] = lv
                if (lv > mx) mx = lv
            }
        }
        val floor = mx - 8f
        for (i in out.indices) {
            val v = if (out[i] < floor) floor else out[i]
            out[i] = (v + 4f) / 4f
        }
        return out
    }

    // ---------------------------------------------------------------- decoding

    /** Returns how many tokens at the end are a pointless loop (0 = no loop). */
    private fun loopTail(g: List<Int>): Int {
        val n = g.size
        for (len in 1..8) {
            val span = max(12, 4 * len)
            if (n < span) continue
            var ok = true
            for (i in 0 until span - len) {
                if (g[n - 1 - i] != g[n - 1 - i - len]) { ok = false; break }
            }
            if (ok) return span - len
        }
        return 0
    }

    /** Average log-probability of the tokens of the last transcription (0 = very sure, below about -1 = Whisper was guessing). */
    @Volatile var lastLogp = 0f

    private val spaces = Regex("\\s+")
    private val junk = Regex("[♪♫*]+")

    /**
     * Transcribes one finished piece of speech (16 kHz mono, up to 30 s). Runs on the caller's thread (the stt thread).
     * Returns the English text, or "" when nothing was heard.
     */
    fun transcribe(filesDir: File, v: String, pcm: ShortArray): String {
        val e = loadEngine(filesDir, v)
        if (pcm.size < SR_MIN) return ""
        val feats = logMel(pcm)
        val inT = OnnxTensor.createTensor(
            e.env, FloatBuffer.wrap(feats), longArrayOf(1, NMEL.toLong(), NFRAMES.toLong())
        )
        val gen = ArrayList<Int>()
        var lpSum = 0.0
        var lpN = 0
        lastLogp = 0f
        try {
            // only the hidden states are needed: the model also has huge attention outputs that we never ask for
            e.enc.run(mapOf("input_features" to inT), setOf("last_hidden_state")).use { encRes ->
                val hidden = encRes[0] as OnnxTensor
                val ids = ArrayList<Int>()
                ids.add(SOT)
                ids.add(NOTS)
                for (step in 0 until MAX_NEW) {
                    val arr = LongArray(ids.size) { ids[it].toLong() }
                    val idT = OnnxTensor.createTensor(e.env, LongBuffer.wrap(arr), longArrayOf(1, arr.size.toLong()))
                    var best = -1
                    try {
                        e.dec.run(
                            mapOf("input_ids" to idT, "encoder_hidden_states" to hidden),
                            setOf("logits")
                        ).use { r ->
                            val fbuf = (r[0] as OnnxTensor).floatBuffer
                            val base = (ids.size - 1) * N_VOCAB
                            var bv = -Float.MAX_VALUE
                            for (i in 0 until N_TEXT) {
                                if (suppressed[i]) continue
                                if (step == 0 && (i == 220 || i == EOT)) continue   // begin_suppress_tokens
                                val lv = fbuf.get(base + i)
                                if (lv > bv) { bv = lv; best = i }
                            }
                            if (best >= 0 && best != EOT) {
                                // how sure Whisper was about this token: probability of the best one among all
                                var se = 0.0
                                for (i in 0 until N_TEXT) { if (!suppressed[i]) se += Math.exp((fbuf.get(base + i) - bv).toDouble()) }
                                if (se > 0.0) { lpSum += -Math.log(se); lpN++ }
                            }
                        }
                    } finally {
                        idT.close()
                    }
                    if (best < 0 || best == EOT) break
                    gen.add(best)
                    ids.add(best)
                    val loop = loopTail(gen)
                    if (loop > 0) {
                        // keep one copy of the repeated part
                        gen.subList(gen.size - loop, gen.size).clear()
                        break
                    }
                }
            }
        } finally {
            inT.close()
        }
        lastLogp = if (lpN > 0) (lpSum / lpN).toFloat() else 0f
        val text = detok(e, gen).replace(junk, " ").replace(spaces, " ").trim()
        // Whisper's well-known inventions on noise / music: a lone "you", or "thanks for watching"
        val low = text.lowercase().replace(Regex("[^a-z ]"), "").trim()
        if (low == "you" || low.startsWith("thanks for watching") || low.startsWith("thank you for watching")) return ""
        return text
    }

    private const val SR_MIN = 4000   // 0.25 s
}
