package com.hardi.kurdishtranslator

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import org.vosk.Model
import java.io.File
import java.util.zip.ZipInputStream

/**
 * ناسینەوەی قسەی ئینگلیزی بە شێوەی ئۆفلاین (Vosk) — بێ ئینتەرنێت و بێ کلیل.
 * تەنها وەرگێڕانی دەق بۆ کوردی ئینتەرنێت دەوێت (Gem.translate).
 * مۆدێلی پێشنیارکراو: vosk-model-small-en-us-0.15 (نزیکەی ٤٠MB).
 *
 * سێ ئامرازی ناسینەوە هەیە و بەکارهێنەر لە ڕێکخستنەکان هەڵیدەبژێرێت:
 *   "vosk" = Vosk (سووک، زیندوو)،  "wq" = Whisper base.en quantized،  "wu" = Whisper base.en uint8.
 * هەڵبژاردنەکە لە SharedPreferences ی "p" پاشەکەوت دەکرێت (کلیلی "stteng").
 */
object Stt {
    private const val TAG = "Stt"
    const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"

    const val ENGINE_VOSK = "vosk"
    const val ENGINE_WQ = "wq"
    const val ENGINE_WU = "wu"

    /** GitHub Release folder that holds the Whisper files (vocab.json + encoder/decoder .onnx). */
    const val WHISPER_BASE = "https://github.com/Whiteheart00/kurdish-voice/releases/download/whisper/"

    private const val PREF_ENGINE = "stteng"
    private const val PREF_BASE = "whbase"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("p", Context.MODE_PRIVATE)

    /** The recognizer the user picked (default: Vosk, so existing installs keep working). */
    fun engine(ctx: Context): String {
        val e = prefs(ctx).getString(PREF_ENGINE, ENGINE_VOSK)
        return if (e == ENGINE_WQ || e == ENGINE_WU) e else ENGINE_VOSK
    }

    fun setEngine(ctx: Context, e: String) {
        prefs(ctx).edit().putString(PREF_ENGINE, e).apply()
    }

    fun isWhisper(e: String) = e == ENGINE_WQ || e == ENGINE_WU

    fun variantOf(e: String) = if (e == ENGINE_WU) Whisper.V_U else Whisper.V_Q

    fun whisperBase(ctx: Context): String =
        (prefs(ctx).getString(PREF_BASE, WHISPER_BASE) ?: WHISPER_BASE).ifBlank { WHISPER_BASE }

    fun setWhisperBase(ctx: Context, url: String) {
        prefs(ctx).edit().putString(PREF_BASE, url.trim()).apply()
    }

    @Volatile private var model: Model? = null
    private val lock = Any()

    fun modelDir(filesDir: File) = File(filesDir, "vosk_en")

    /** A Vosk model folder always has conf/model.conf and an "am" folder. */
    private fun valid(d: File) = File(d, "conf/model.conf").exists() && File(d, "am").isDirectory

    /** Is the model of the SELECTED recognizer installed? */
    fun isInstalled(ctx: Context): Boolean = isInstalled(ctx, engine(ctx))

    fun isInstalled(ctx: Context, e: String): Boolean =
        if (isWhisper(e)) Whisper.isInstalled(ctx.filesDir, variantOf(e)) else valid(modelDir(ctx.filesDir))

    fun reset() {
        synchronized(lock) {
            try { model?.close() } catch (_: Throwable) {}
            model = null
        }
    }

    /** Loads the model once (takes a few seconds on the first call). */
    fun load(filesDir: File): Model {
        model?.let { return it }
        synchronized(lock) {
            model?.let { return it }
            val d = modelDir(filesDir)
            if (!valid(d)) throw RuntimeException("مۆدێلی گوێگرتنی ئینگلیزی نەهێنراوە (دوگمەی «مۆدێلی گوێگرتن»)")
            val m = Model(d.absolutePath)
            model = m
            return m
        }
    }

    private fun displayName(ctx: Context, uri: Uri): String =
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        } catch (_: Exception) { null } ?: uri.lastPathSegment.orEmpty()

    /** Unpacks a model zip into [dest]; the zip's single top folder (vosk-model-.../) is stripped. */
    private fun unzip(ins: java.io.InputStream, dest: File): String? {
        val tmp = File(dest.parentFile, dest.name + ".tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        ZipInputStream(ins.buffered()).use { zin ->
            while (true) {
                val en = zin.nextEntry ?: break
                if (en.isDirectory) continue
                val target = File(tmp, en.name)
                // zip-slip guard
                if (!target.canonicalPath.startsWith(tmp.canonicalPath + File.separator)) continue
                target.parentFile?.mkdirs()
                target.outputStream().use { zin.copyTo(it) }
            }
        }
        // find the folder that really holds conf/ and am/ (directly, or one level down)
        val root = if (valid(tmp)) tmp else tmp.listFiles()?.firstOrNull { it.isDirectory && valid(it) }
        if (root == null) {
            tmp.deleteRecursively()
            return "ئەم zip ـە مۆدێلی Vosk نییە (am/ و conf/ ی تێدا نییە)"
        }
        dest.deleteRecursively()
        if (!root.renameTo(dest)) {
            tmp.deleteRecursively()
            return "نەتوانرا مۆدێلەکە دابنرێت"
        }
        tmp.deleteRecursively()
        return null
    }

    /** Imports a Vosk model zip chosen by the user. null = ok, otherwise an error message. Call on a worker thread. */
    fun importModel(ctx: Context, uri: Uri): String? {
        reset()
        return try {
            val name = displayName(ctx, uri).lowercase()
            if (!name.endsWith(".zip")) return "zip ی مۆدێلی Vosk هەڵبژێرە ($name)"
            val ins = ctx.contentResolver.openInputStream(uri) ?: return "فایلەکە نەکرایەوە"
            ins.use { unzip(it, modelDir(ctx.filesDir)) }
        } catch (e: Throwable) {
            Log.e(TAG, "import failed", e)
            "هێنان سەرنەکەوت: ${e.message}"
        }
    }

    /** Downloads the model of the SELECTED recognizer (resumes after a network drop). null = ok. Call on a worker thread. */
    fun download(ctx: Context, progress: (Int) -> Unit): String? {
        val e = engine(ctx)
        if (isWhisper(e)) return Whisper.download(ctx.filesDir, variantOf(e), whisperBase(ctx), progress)
        return downloadVosk(ctx, progress)
    }

    /** Downloads the small Vosk English model once; resumes a partial download after a network drop. null = ok. */
    private fun downloadVosk(ctx: Context, progress: (Int) -> Unit): String? {
        reset()
        val zip = File(Downloader.dir(ctx.filesDir), "vosk_en.zip.part")
        Downloader.fetch(zip, MODEL_URL, progress)?.let { return it }
        return try {
            zip.inputStream().use { unzip(it, modelDir(ctx.filesDir)) }
        } catch (e: Throwable) {
            Log.e(TAG, "download failed", e)
            "داگرتن سەرنەکەوت: ${e.message}"
        } finally {
            zip.delete()   // zip ی تەواو و ئێستا کراوەتەوە (یان ناتەواو بوو) — لە سفرەوە دەست پێدەکاتەوە
        }
    }
}
