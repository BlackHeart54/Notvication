package com.hardi.kurdishtranslator

/**
 * ئامادەکردنی دەق پێش خوێندنەوە. مۆدێلەکە تەنها ٤٨ هێمای هەیە (پیتی کوردی و چەند خاڵبەندییەک)،
 * هەر شتێکی تر (ژمارە، کۆما، کەوانە...) بێدەنگ فڕێ دەدرا و ڕستەکە ناتەواو دەخوێنرایەوە.
 * ئێرە ژمارەکان دەکاتە وشەی کوردی و خاڵبەندییەکان دەگۆڕێت بۆ ئەوانەی مۆدێلەکە دەیانناسێت.
 */
object KuText {
    private val ones = arrayOf("سفر", "یەک", "دوو", "سێ", "چوار", "پێنج", "شەش", "حەوت", "هەشت", "نۆ")
    private val teens = arrayOf("دە", "یازدە", "دوازدە", "سیازدە", "چواردە", "پازدە", "شازدە", "حەڤدە", "هەژدە", "نۆزدە")
    private val tens = arrayOf("", "", "بیست", "سی", "چل", "پەنجا", "شەست", "حەفتا", "هەشتا", "نەوەد")

    private fun below1000(n: Int): String {
        val parts = ArrayList<String>()
        val h = n / 100
        val r = n % 100
        if (h > 0) parts.add(if (h == 1) "سەد" else ones[h] + " سەد")
        if (r > 0) {
            when {
                r < 10 -> parts.add(ones[r])
                r < 20 -> parts.add(teens[r - 10])
                else -> {
                    val o = r % 10
                    parts.add(if (o == 0) tens[r / 10] else tens[r / 10] + " و " + ones[o])
                }
            }
        }
        return parts.joinToString(" و ")
    }

    /** ژمارە ← وشەی کوردی (تا ملیار). نموونە: 125 ← «سەد و بیست و پێنج». */
    fun words(n: Long): String {
        if (n == 0L) return ones[0]
        val parts = ArrayList<String>()
        var rest = n
        val units = arrayOf("", "هەزار", "ملیۆن", "ملیار")
        val chunks = ArrayList<Int>()
        while (rest > 0) { chunks.add((rest % 1000).toInt()); rest /= 1000 }
        for (i in chunks.indices.reversed()) {
            val c = chunks[i]
            if (c == 0 || i >= units.size) continue
            parts.add(
                when {
                    i == 0 -> below1000(c)
                    c == 1 -> units[i]
                    else -> below1000(c) + " " + units[i]
                }
            )
        }
        return parts.joinToString(" و ")
    }

    private fun digitsOneByOne(s: String) = s.map { ones[it - '0'] }.joinToString(" ")

    /** دەقی ئامادەکراو بۆ مۆدێلی دەنگ. */
    fun prepare(raw: String): String {
        // ژمارەی عەرەبی/فارسی ← ئەسکی
        val sb = StringBuilder(raw.length)
        for (c in raw) {
            sb.append(
                when (c) {
                    in '\u0660'..'\u0669' -> '0' + (c - '\u0660')
                    in '\u06F0'..'\u06F9' -> '0' + (c - '\u06F0')
                    else -> c
                }
            )
        }
        var t = sb.toString()

        // جیاکەرەوەی هەزارەکان: 1,000 ← 1000
        t = t.replace(Regex("(?<=\\d),(?=\\d{3}(?!\\d))"), "")
        t = t.replace("%", " لە سەد ").replace("٪", " لە سەد ")
        // ژمارەی ڕێژەیی: 3.5 ← سێ پۆینت پێنج
        t = t.replace(Regex("(\\d+)[.\u066B](\\d+)")) { m ->
            val a = m.groupValues[1]
            val b = m.groupValues[2]
            (if (a.length > 12) digitsOneByOne(a) else words(a.toLong())) + " پۆینت " + digitsOneByOne(b)
        }
        t = t.replace(Regex("\\d+")) { m ->
            val d = m.value
            " " + (if (d.length > 12) digitsOneByOne(d) else words(d.toLong())) + " "
        }

        // خاڵبەندی: ئەوانەی مۆدێلەکە دەیانناسێت (، ؛ ؟ ! . :)
        t = t.replace("...", ".").replace("…", ".")
            .replace(',', '،').replace('?', '؟').replace(';', '؛')
            .replace('—', '،').replace('–', '،')
            .replace("&", " و ")
        val drop = "()[]{}«»“”„\"'`*#_~/\\|<>=+@^$•·"
        val out = StringBuilder(t.length)
        for (c in t) out.append(if (drop.indexOf(c) >= 0 || c == '-') ' ' else c)
        t = out.toString()

        // خاڵبەندیی دووبارە: «؟!» ← «؟»
        t = t.replace(Regex("([.!؟])[.!؟]+"), "$1")
            .replace(Regex("([،؛])\\s*([،؛])+"), "$1")
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex(" ?([،؛.!؟:])"), "$1")
        return t.trim()
    }
}
