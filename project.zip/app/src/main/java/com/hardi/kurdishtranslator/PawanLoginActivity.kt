package com.hardi.kurdishtranslator

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout

/** یەک جار بچۆ ژوورەوە؛ cookieـەکان دەمێننەوە و PawanTts بەکاریان دەهێنێت. */
class PawanLoginActivity : Activity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.loadUrl(PawanTts.URL)

        val done = Button(this).apply {
            text = "تەواو بوو"
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFF7C3AED.toInt())
            setOnClickListener {
                CookieManager.getInstance().flush()
                PawanTts.reload()
                finish()
            }
        }
        val root = FrameLayout(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        root.addView(done, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
    }

    override fun onPause() {
        CookieManager.getInstance().flush()
        super.onPause()
    }
}
