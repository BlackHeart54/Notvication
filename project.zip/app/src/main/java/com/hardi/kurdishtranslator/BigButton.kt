package com.hardi.kurdishtranslator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.min

/** The big round start / stop button: green with a microphone when idle, red with a stop square while running. */
class BigButton(ctx: Context) : View(ctx) {
    var running = false
        set(v) {
            if (field != v) {
                field = v
                invalidate()
            }
        }

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()

    override fun onMeasure(w: Int, h: Int) {
        val s = min(MeasureSpec.getSize(w).takeIf { it > 0 } ?: 600, MeasureSpec.getSize(h).takeIf { it > 0 } ?: 600)
        setMeasuredDimension(s, s)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f
        val main = if (running) 0xFFEF4444.toInt() else 0xFF22C55E.toInt()
        val dark = if (running) 0xFF991B1B.toInt() else 0xFF0F7A3A.toInt()
        val light = if (running) 0xFFFB7185.toInt() else 0xFF4ADE80.toInt()

        // soft glow + two thin rings around the button
        fill.shader = RadialGradient(cx, cy, r, intArrayOf((main and 0x00FFFFFF) or 0x55000000, (main and 0x00FFFFFF)), floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, fill)
        ring.strokeWidth = r * 0.015f
        ring.color = (main and 0x00FFFFFF) or 0x99000000.toInt()
        c.drawCircle(cx, cy, r * 0.82f, ring)
        ring.color = (main and 0x00FFFFFF) or 0x44000000
        c.drawCircle(cx, cy, r * 0.93f, ring)

        // the button itself
        val br = r * 0.68f
        fill.shader = RadialGradient(cx - br * 0.3f, cy - br * 0.4f, br * 1.5f, intArrayOf(light, main, dark), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, br, fill)
        fill.shader = null

        if (running) {
            val h = br * 0.3f
            rect.set(cx - h, cy - h, cx + h, cy + h)
            ink.style = Paint.Style.FILL
            c.drawRoundRect(rect, h * 0.3f, h * 0.3f, ink)
        } else {
            val u = br
            ink.style = Paint.Style.FILL
            rect.set(cx - 0.2f * u, cy - 0.52f * u, cx + 0.2f * u, cy + 0.1f * u)
            c.drawRoundRect(rect, 0.2f * u, 0.2f * u, ink)
            ink.style = Paint.Style.STROKE
            ink.strokeWidth = 0.075f * u
            rect.set(cx - 0.36f * u, cy - 0.3f * u, cx + 0.36f * u, cy + 0.34f * u)
            c.drawArc(rect, 0f, 180f, false, ink)
            c.drawLine(cx, cy + 0.34f * u, cx, cy + 0.54f * u, ink)
            c.drawLine(cx - 0.2f * u, cy + 0.54f * u, cx + 0.2f * u, cy + 0.54f * u, ink)
        }
    }
}
