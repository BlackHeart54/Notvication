package com.hardi.kurdishtranslator

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * English -> Sorani Kurdish with Google Translate and NO key (same free routes as the manga project).
 * Used when no Gemini key is set (or when Gemini fails). Must be called from a background thread.
 */
object GoogleFree {
    private const val TAG = "GoogleFree"

    private val cache = object : LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 800
    }

    fun enToKu(text: String): String {
        val t = text.trim()
        if (t.isEmpty()) return ""
        synchronized(cache) { cache[t] }?.let { return it }
        var failure: IOException? = null
        repeat(2) {
            try {
                val out = free(t)
                if (out.isNotBlank()) {
                    synchronized(cache) { cache[t] = out }
                    return out
                }
            } catch (e: IOException) {
                Log.w(TAG, "attempt failed: " + e.message)
                if (failure == null) failure = e
            }
        }
        throw failure ?: IOException("وەرگێڕان شکستی هێنا")
    }

    private fun free(text: String): String {
        val q = URLEncoder.encode(text, "UTF-8")
        try {
            val res = request("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ckb&dt=t&q=$q")
            val parts = JSONArray(res).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val seg = parts.optJSONArray(i) ?: continue
                if (!seg.isNull(0)) sb.append(seg.getString(0))
            }
            if (sb.isNotBlank()) return sb.toString().trim()
        } catch (e: Exception) {
            Log.w(TAG, "gtx failed: " + e.message)
        }
        try {
            val res = request("https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=en&tl=ckb&q=$q").trim()
            val out = if (res.startsWith("{")) {
                val ss = JSONObject(res).getJSONArray("sentences")
                val sb = StringBuilder()
                for (i in 0 until ss.length()) sb.append(ss.getJSONObject(i).optString("trans", ""))
                sb.toString().trim()
            } else {
                val first = JSONArray(res).get(0)
                (if (first is JSONArray) first.getString(0) else first.toString()).trim()
            }
            if (out.isNotBlank()) return out
        } catch (e: Exception) {
            Log.w(TAG, "clients5 failed: " + e.message)
        }
        return try {
            val html = request("https://translate.google.com/m?sl=en&tl=ckb&q=$q")
            val m = Regex("class=\"result-container\">(.*?)</div>", RegexOption.DOT_MATCHES_ALL).find(html)
                ?: throw IOException("no result")
            android.text.Html.fromHtml(m.groupValues[1], android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim()
        } catch (e: Exception) {
            throw IOException("Google: " + e.message)
        }
    }

    private fun request(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 5_000
            c.readTimeout = 8_000
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("HTTP $code")
            return text
        } finally {
            c.disconnect()
        }
    }
}
