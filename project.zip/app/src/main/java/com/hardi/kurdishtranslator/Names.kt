package com.hardi.kurdishtranslator

/**
 * ناوی کەس و شوێنەکانی یاری. کاربەر لیستێک دەنووسێت، هەر دێڕێک:
 *     Sasuke
 *     Naruto, Narooto, Naruto's = ناڕوتۆ
 * (لای چەپ: ناوی ئینگلیزی، پاشان ئەگەر بتەوێت شێوەی هەڵەی ناسینەوە بە کۆما؛ لای ڕاست «=» دوای ئەوە شێوەی کوردی ئەگەر بتەوێت.)
 *
 * دوو کار دەکات:
 *  1) fix(): دوای ناسینەوە، وشەیەک کە زۆر لە ناوێک دەچێت (یان چەند وشەیەک کە بە یەکەوە دەبنە ناوەکە، وەک «sas uke») دەکرێتە ناوە ڕاستەکە.
 *  2) promptFor() / applyKu(): لە وەرگێڕانی Gemini ناوەکان بە هەمان شێوەی کوردی دەنووسرێن، و ئەگەر پیتی لاتینی مابوو دەگۆڕدرێت.
 */
object Names {
    class Entry(val canon: String, val keys: List<String>, val ku: String?)

    @Volatile private var list: List<Entry> = emptyList()

    fun load(text: String?) {
        val out = ArrayList<Entry>()
        for (raw in (text ?: "").lines()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val eq = line.indexOf('=')
            val left = (if (eq >= 0) line.substring(0, eq) else line).trim()
            val ku = if (eq >= 0) line.substring(eq + 1).trim().ifEmpty { null } else null
            val names = left.split(',').map { it.trim() }.filter { it.isNotEmpty() }
            if (names.isEmpty()) continue
            out.add(Entry(names[0], names, ku))
        }
        list = out
    }

    fun count() = list.size

    // ---- matching helpers
    private val tok = Regex("[A-Za-z][A-Za-z']*")

    // words that must never be replaced by a fuzzy match (common English words close to many names)
    private val common = setOf(
        "the", "and", "you", "are", "was", "for", "not", "but", "can", "his", "her", "him", "she", "they", "them", "with", "this", "that",
        "have", "has", "had", "will", "would", "could", "should", "what", "when", "where", "who", "why", "how", "now", "then", "there",
        "here", "from", "into", "over", "just", "like", "come", "go", "get", "got", "see", "look", "stop", "wait", "help", "run", "move",
        "down", "back", "away", "left", "right", "ready", "enemy", "enemies", "behind", "again", "over", "kill", "fire", "cover", "watch",
        "later", "layer", "lane", "lain", "king", "kind", "mine", "main", "mind", "more", "most", "move", "name", "need", "never", "next"
    )

    private fun norm(s: String) = s.lowercase().filter { it.isLetter() }

    /** A rough sound key: similar-sounding spellings give the same key. */
    private fun sound(s: String): String {
        val x = norm(s)
            .replace("ph", "f").replace("ck", "k").replace("kh", "k").replace("sh", "s").replace("ch", "s")
            .replace("c", "k").replace("q", "k").replace("x", "ks").replace("z", "s").replace("v", "f").replace("w", "u").replace("y", "i")
        val sb = StringBuilder()
        for ((i, c) in x.withIndex()) {
            if (i > 0 && c in "aeiouh") continue          // vowels (after the first letter) and h do not count
            if (sb.isNotEmpty() && sb.last() == c) continue
            sb.append(c)
        }
        return sb.toString()
    }

    private fun lev(a: String, b: String): Int {
        val prev = IntArray(b.length + 1) { it }
        val cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val c = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + c)
            }
            System.arraycopy(cur, 0, prev, 0, prev.size)
        }
        return prev[b.length]
    }

    private fun matchEntry(cand: String): Entry? {
        if (cand.length < 3) return null
        for (e in list) {
            for (k in e.keys) {
                val kn = norm(k)
                if (kn.length < 3) continue
                if (cand == kn) return e
            }
        }
        if (cand in common) return null
        var best: Entry? = null
        var bestD = Int.MAX_VALUE
        for (e in list) {
            for (k in e.keys) {
                val kn = norm(k)
                if (kn.length < 4 || Math.abs(kn.length - cand.length) > 2) continue
                val sc = sound(cand)
                val sk = sound(kn)
                val allowed = if (kn.length <= 5) 1 else if (kn.length <= 9) 2 else 3
                val d = lev(cand, kn)
                // same first sound, and either a small spelling distance or the same rough sound
                val ok = sc.isNotEmpty() && sk.isNotEmpty() && sc[0] == sk[0] &&
                    (d <= allowed || (sc == sk && kn.length >= 5))
                if (ok && d < bestD) { best = e; bestD = d }
            }
        }
        return best
    }

    /** English text from the recogniser -> the same text with the game's names written correctly. */
    fun fix(en: String): String {
        if (list.isEmpty()) return en
        val toks = tok.findAll(en).toList()
        if (toks.isEmpty()) return en
        val sb = StringBuilder()
        var pos = 0
        var i = 0
        while (i < toks.size) {
            var hit: Entry? = null
            var used = 0
            for (n in 3 downTo 1) {
                if (i + n > toks.size) continue
                val a = toks[i].range.first
                val b = toks[i + n - 1].range.last + 1
                val span = en.substring(a, b)
                if (n > 1 && !span.all { it.isLetter() || it == ' ' || it == '\'' }) continue   // a comma / full stop between the words: not one name
                val e = matchEntry(norm(span))
                if (e != null) { hit = e; used = n; break }
            }
            if (hit != null) {
                sb.append(en, pos, toks[i].range.first)
                sb.append(hit.canon)
                pos = toks[i + used - 1].range.last + 1
                i += used
            } else i++
        }
        sb.append(en.substring(pos))
        return sb.toString()
    }

    /** Names that appear in [lines], as a short instruction for Gemini ("" when there are none). */
    fun promptFor(lines: List<String>): String {
        if (list.isEmpty()) return ""
        val all = lines.joinToString(" ").lowercase()
        val hits = list.filter { e -> e.keys.any { all.contains(it.lowercase()) } }
        if (hits.isEmpty()) return ""
        val sb = StringBuilder("Names in these lines — write each one EXACTLY like this in the Kurdish text, never in Latin letters: ")
        sb.append(hits.joinToString("; ") { e -> e.canon + (if (e.ku != null) " = " + e.ku else " (transliterate into Kurdish letters, same spelling every time)") })
        sb.append(". ")
        return sb.toString()
    }

    /** Safety net: a name that is still in Latin letters in the Kurdish text becomes its Kurdish form. */
    fun applyKu(ku: String): String {
        var s = ku
        for (e in list) {
            val k = e.ku ?: continue
            for (name in e.keys) {
                if (name.length < 3) continue
                s = Regex("\\b" + Regex.escape(name) + "\\b", RegexOption.IGNORE_CASE).replace(s, k)
            }
        }
        return s
    }
}
